ScoutX Companion fuer macOS

1. ZIP entpacken.
2. install.command oeffnen.
3. Danach in ScoutX 'Verbindung erneut pruefen' anklicken.

Der Companion laeuft lokal auf 127.0.0.1:8791 und startet per LaunchAgent beim Login.
Node.js/npm muessen installiert sein.
