#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

APP_DIR="$HOME/Library/Application Support/ScoutX Companion"
LOG_DIR="$HOME/Library/Logs/ScoutX"
LABEL="com.scoutx.hrworks-companion"
PLIST_PATH="$HOME/Library/LaunchAgents/$LABEL.plist"
DOMAIN="gui/$(id -u)"
NODE_BIN="$(command -v node || true)"
NPM_BIN="$(command -v npm || true)"

if [[ -z "$NODE_BIN" || -z "$NPM_BIN" ]]; then
  echo "Node.js und npm muessen installiert sein. Installiere Node.js von https://nodejs.org und starte diesen Installer erneut."
  read -r -p "Enter zum Schliessen..."
  exit 1
fi

mkdir -p "$APP_DIR" "$LOG_DIR" "$HOME/Library/LaunchAgents"
rsync -a --delete payload/ "$APP_DIR/"
cd "$APP_DIR"
"$NPM_BIN" install --no-audit --no-fund

cat > "$PLIST_PATH" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>$LABEL</string>
  <key>ProgramArguments</key>
  <array>
    <string>$NODE_BIN</string>
    <string>$APP_DIR/scripts/hrworks-automation-bridge.mjs</string>
  </array>
  <key>WorkingDirectory</key>
  <string>$APP_DIR</string>
  <key>RunAtLoad</key>
  <true/>
  <key>KeepAlive</key>
  <true/>
  <key>StandardOutPath</key>
  <string>$LOG_DIR/hrworks-companion.out.log</string>
  <key>StandardErrorPath</key>
  <string>$LOG_DIR/hrworks-companion.err.log</string>
  <key>EnvironmentVariables</key>
  <dict>
    <key>PATH</key>
    <string>/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin</string>
  </dict>
</dict>
</plist>
PLIST

chmod 644 "$PLIST_PATH"
launchctl bootout "$DOMAIN" "$PLIST_PATH" >/dev/null 2>&1 || true
launchctl bootstrap "$DOMAIN" "$PLIST_PATH"
launchctl enable "$DOMAIN/$LABEL" >/dev/null 2>&1 || true
launchctl kickstart -k "$DOMAIN/$LABEL"

echo "ScoutX Companion wurde installiert."
curl -fsS --max-time 5 http://127.0.0.1:8791/health >/dev/null && echo "Companion ist erreichbar auf 127.0.0.1:8791."
read -r -p "Enter zum Schliessen..."
