#!/usr/bin/env bash
set -euo pipefail
LABEL="com.scoutx.hrworks-companion"
DOMAIN="gui/$(id -u)"
PLIST_PATH="$HOME/Library/LaunchAgents/$LABEL.plist"
APP_DIR="$HOME/Library/Application Support/ScoutX Companion"
launchctl bootout "$DOMAIN" "$PLIST_PATH" >/dev/null 2>&1 || true
rm -f "$PLIST_PATH"
rm -rf "$APP_DIR"
echo "ScoutX Companion wurde entfernt."
read -r -p "Enter zum Schliessen..."
