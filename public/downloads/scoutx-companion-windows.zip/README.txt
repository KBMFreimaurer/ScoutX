ScoutX Companion fuer Windows

1. ZIP entpacken.
2. install.bat oeffnen.
3. Danach in ScoutX 'Verbindung erneut pruefen' anklicken.

Der Companion laeuft lokal auf 127.0.0.1:8791 und startet per Windows Aufgabenplanung beim Login.
Node.js/npm muessen installiert sein.
