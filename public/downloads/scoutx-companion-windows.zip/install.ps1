$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$AppDir = Join-Path $env:LOCALAPPDATA "ScoutX Companion"
$LogDir = Join-Path $AppDir "logs"
$Node = (Get-Command node -ErrorAction SilentlyContinue).Source
$Npm = (Get-Command npm -ErrorAction SilentlyContinue).Source
if (-not $Node -or -not $Npm) {
  Write-Host "Node.js und npm muessen installiert sein. Installiere Node.js von https://nodejs.org und starte diesen Installer erneut."
  exit 1
}
New-Item -ItemType Directory -Force -Path $AppDir, $LogDir | Out-Null
Copy-Item -Recurse -Force (Join-Path $Root "payload\*") $AppDir
Push-Location $AppDir
& $Npm install --no-audit --no-fund
Pop-Location
$TaskName = "ScoutX HRworks Companion"
$Script = Join-Path $AppDir "scripts\hrworks-automation-bridge.mjs"
$Action = New-ScheduledTaskAction -Execute $Node -Argument "`"$Script`"" -WorkingDirectory $AppDir
$Trigger = New-ScheduledTaskTrigger -AtLogOn
$Principal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive -RunLevel LeastPrivilege
$Settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1)
Register-ScheduledTask -TaskName $TaskName -Action $Action -Trigger $Trigger -Principal $Principal -Settings $Settings -Force | Out-Null
Start-ScheduledTask -TaskName $TaskName
Write-Host "ScoutX Companion wurde installiert."
Start-Sleep -Seconds 3
try {
  Invoke-RestMethod -Uri "http://127.0.0.1:8791/health" -TimeoutSec 5 | Out-Null
  Write-Host "Companion ist erreichbar auf 127.0.0.1:8791."
} catch {
  Write-Host "Companion startet noch nicht. Pruefe die Windows Aufgabenplanung und die Logs unter $LogDir."
}
