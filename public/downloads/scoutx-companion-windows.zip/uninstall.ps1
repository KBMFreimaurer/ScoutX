$ErrorActionPreference = "Stop"
$TaskName = "ScoutX HRworks Companion"
$AppDir = Join-Path $env:LOCALAPPDATA "ScoutX Companion"
Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
Remove-Item -Recurse -Force $AppDir -ErrorAction SilentlyContinue
Write-Host "ScoutX Companion wurde entfernt."
